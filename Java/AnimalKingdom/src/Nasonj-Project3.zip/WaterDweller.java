
public interface WaterDweller {

	boolean breathesAir();

}
