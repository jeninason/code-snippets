
public interface Winged {

	boolean canFly();
}
