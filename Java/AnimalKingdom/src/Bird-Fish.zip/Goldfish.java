
public class Goldfish extends Fish {

	public static final String GOLDFISH_DESCRIPTION = "Goldfish";
	
	public Goldfish(int id, String name) {
		super(id, name);
	}
	public Goldfish(int id, String name, BirthType birthType) {
		super(id, name, birthType);
	}
	
	@Override
	public String getDescription() {
		String outString =  super.getDescription() + "\t" + GOLDFISH_DESCRIPTION + "\t("
				+ (super.isWarmBlooded() ? "Warm Blooded" : "Cold Blooded") +")";
		return outString;
	}

	
}
