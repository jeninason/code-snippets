
public interface Endangered {
	
	void displayConservationInformation();

}
