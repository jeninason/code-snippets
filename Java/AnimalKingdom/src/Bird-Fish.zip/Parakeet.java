
public class Parakeet extends Bird {

	private String description;
	
	public Parakeet(int id, String name) {
		super(id, name);
		this.description = "Parakeet";
	}
	
	@Override
	public String getDescription() {
		String outString =  super.getDescription() + "\t"+description+"\t("
				+ (super.isWarmBlooded() ? "Warm Blooded" : "Cold Blooded") +")"
				+ (super.canFly() ? "Can Fly" : "Can't Fly");
		return outString;
	}


}
