
public class GreatWhiteShark extends Fish {

	public static final String GREATWHITE_DESCRIPTION = "Great White Shark";
	public static final BirthType GREATWHITE_BIRTH_TYPE = BirthType.LIVE_BIRTH;
	
	public GreatWhiteShark(int id, String name) {
		super(id, name, GREATWHITE_BIRTH_TYPE);
	}
	
	public GreatWhiteShark(int id, String name, BirthType birthType) {
		super(id, name, birthType);
	}

	@Override
	public String getDescription() {
		String outString =  super.getDescription() + "\t" + GREATWHITE_DESCRIPTION + "\t("
				+ (super.isWarmBlooded() ? "Warm Blooded" : "Cold Blooded") +")";
		return outString;
	}
	
}
