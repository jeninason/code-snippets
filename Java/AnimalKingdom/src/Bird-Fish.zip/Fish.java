
public abstract class Fish extends Animal implements WaterDweller {

	public static final String FISH_DESCRIPTION = "Fish";
	public static final boolean BREATHE_AIR = false;
	public static final boolean WARM_BLOOD = false;
	public static final BirthType FISH_BIRTH_TYPE = BirthType.LAYS_EGGS;
	
	public Fish(int id, String name) {
		super(id,name,FISH_BIRTH_TYPE);
	}
	
	public Fish(int id, String name, BirthType birthType) {
		super(id, name, birthType);
	}

	public boolean isWarmBlooded() {
		return WARM_BLOOD; //fish are cold blooded
	}

	public String getDescription() {
		return FISH_DESCRIPTION; //baffled
	}

	public boolean breathesAir() {
		return BREATHE_AIR;
	}
	
}
